--
-- Implementa'c~ao de um meio somador com duas portas lógicas
--
--	'Ultima atualiza'c~ao: 22/08/2025
--
library IEEE;
use IEEE.std_logic_1164.all; --necessa'rio para o uso do tipo std_logic

entity halfadd is
port (A, B: in std_logic;
      Sum, Carry: out std_logic);
end halfadd;

architecture halfadd of halfadd is
begin
  Sum   <= A xor B; -- função xor, somar os dois bits
  Carry <= A and B; -- gera o "vai um" da soma
end halfadd;
