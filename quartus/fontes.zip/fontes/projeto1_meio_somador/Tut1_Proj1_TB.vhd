--
-- Testbench para o meio somador
--
--	'Ultima atualiza'c~ao: 22/08/2025
--
library IEEE;
use IEEE.std_logic_1164.all;

entity halfadd_tb is
end halfadd_tb;

architecture TB_ARCHITECTURE of halfadd_tb is
  signal aa, bb, soma, vaium : std_logic;
  -- Este sinais poderiam ter nomes iguais `as entradas/sa'idas do somador
  -- Est~ao com nomes diferentes para ilustrar a sintaxe do comando port map
begin

  UUT : entity work.halfadd -- biblioteca work 
			-- sempre existe a bib work, e ela conte'm todos os pares E/A 
			-- compilados no projeto
        port map ( A => aa, B => bb, 
                   Sum => soma, Carry => vaium );
			-- `a esquerda do operador => esta' o pino e `a direita o fio
			-- externo onde este se conecta

  aa <= '0', '1' after 10 ns, '0' after 20 ns, '1' after 30 ns;	
		-- Gerador de esti'mulos para a entrada A do somador
  bb <= '0', '1' after 20 ns;								   	
		-- Gerador de esti'mulos para a entrada B do somador 	

end TB_ARCHITECTURE;
