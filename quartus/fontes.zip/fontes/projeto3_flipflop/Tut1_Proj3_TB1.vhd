--
-- Testbench para validar o Hw de um dos flip-flops D do CI TTL 74LS74
--		Aqui, usa-se a arquitetura não-hier'arquica (codeonly_arch)
--		É simples trocar para uma das arquiteturas hier'arquicas
--
--	'Ultima atualiza'c~ao: 25/08/2025
--
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;


entity flip_flop_d_es_tb1 is
end flip_flop_d_es_tb1;

architecture flip_flop_d_es_tb1 of flip_flop_d_es_tb1 is
  signal preset, clear : std_logic;
  signal clk : std_logic:= '0';
  signal ent  : std_logic:= '0';
  signal saida, saida_n: std_logic;

begin

  UUT : entity work.flip_flop_d_es(codeonly_arch)
        port map	( pre_n => preset, clr_n => clear, 
                    d => ent, clk => clk,
						  q => saida, q_n => saida_n);

  preset <= '1', '0' after 11ns, '1' after 21ns;
  clear  <= '1', '0' after 28ns, '1' after 41ns;

  clk	<= not clk after 5ns;
  ent	<= '0', '1' after 22ns, '0' after 62ns; 
	

end flip_flop_d_es_tb1;
