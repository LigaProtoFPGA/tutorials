--
-- Uma entidade e 3 arquiteturas distintas para modelar o Hw de um dos 
--	flip-flops D do CI TTL 74LS74. As arquiteturas (ou seja, 
--	implementa,c~oes) diferem pelo grau de hierarquia (com/sem) e/ou 
--	pelo n'ivel de granularidade do nível hier'arquico inferior
--	(porta/latch). As arquiteturas contemplam:
--		1) Uma implementa'c~ao "achatada" ("flat"), sem hierarquia
--			codeonly_arch
--		2) Uma implementa'c~ao com 2 n'iveis hier'arquicos (porta NAND
--			de 3 entradas composta com fios) - nand3i_arch
--		3) Uma implementa'c~ao com 2 n'iveis hier'arquicos (latch com 4
--			entradas composta com fios) - latch_arch
--	Observação: Requer um ou mais arquivos adicionais com a descrição dos
--			pares entidade/arquitetura (E/A) dos elementos nand e latch:
--			1) Porta NAND de 3 entradas - E/A nand3i
--			2) Latch de 4 entradas, 2 sa'idas - E/A latch_4ctrls
--
--	'Ultima atualiza'c~ao: 24/08/2025
--
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

entity flip_flop_d_es is
port (pre_n, clr_n, clk, d	: in std_logic;
      q, q_n	      		: out std_logic
     );
end flip_flop_d_es;

architecture codeonly_arch of flip_flop_d_es is
   signal o_nand3_1, o_nand3_2, o_nand3_3,
			 o_nand3_4, o_nand3_5, o_nand3_6 : std_logic;
	-- Seis sinais, correspondendo `as sa'idas das 6 portas NAND de 3 entradas
begin
	
	o_nand3_1 <= not (pre_n and o_nand3_4 and o_nand3_2);
	o_nand3_2 <= not (o_nand3_1 and clr_n and clk);
	o_nand3_3 <= not (o_nand3_2 and clk and o_nand3_4);
	o_nand3_4 <= not (o_nand3_3 and clr_n and d);
	o_nand3_5 <= not (pre_n and o_nand3_2 and o_nand3_6);
	o_nand3_6 <= not (o_nand3_5 and clr_n and o_nand3_3);
	
	q		<= o_nand3_5;
	q_n		<= o_nand3_6;
  
end codeonly_arch;

architecture nand3i_arch of flip_flop_d_es is
   signal o_nand3_1, o_nand3_2, o_nand3_3, 
			 o_nand3_4, o_nand3_5, o_nand3_6 : std_logic;
	-- Seis sinais correspondendo `as sa'idas das 6 portas NAND de 3 entradas
begin
	
nand3_1: entity work.nand3i
        port map	( A=>pre_n, B=>o_nand3_4, C=>o_nand3_2, Outp=>o_nand3_1);
nand3_2: entity work.nand3i
        port map	( A=>o_nand3_1, B=>clr_n, C=>clk, Outp=>o_nand3_2);
nand3_3: entity work.nand3i
        port map	( A=>o_nand3_2, B=>clk, C=>o_nand3_4, Outp=>o_nand3_3);
nand3_4: entity work.nand3i
        port map	( A=>o_nand3_3, B=>clr_n, C=>d, Outp=>o_nand3_4);
nand3_5: entity work.nand3i
        port map	( A=>pre_n, B=>o_nand3_2, C=>o_nand3_6, Outp=>o_nand3_5);
nand3_6: entity work.nand3i
        port map	( A=>o_nand3_5, B=>clr_n, C=>o_nand3_3, Outp=>o_nand3_6);

	q		<= o_nand3_5;
	q_n	<= o_nand3_6;
  
end nand3i_arch;

architecture latch_arch of flip_flop_d_es is
   signal q_n_l1, q_l2, q_n_l2 : std_logic;
	-- S~ao necess'arios apenas tr^es fios internos 
begin
	
l1: entity work.latch_4ctrls
        port map (C1=>pre_n, C2=>q_n_l2, C3=>clr_n, C4=>clk,
						Q=>open, Q_N=>q_n_l1);
l2: entity work.latch_4ctrls
        port map (C1=>q_n_l1, C2=>clk, C3=>clr_n, C4=>d,
						Q=>q_l2, Q_N=>q_n_l2);
l3: entity work.latch_4ctrls
        port map (C1=>pre_n, C2=>q_n_l1, C3=>clr_n, C4=>q_l2,
						Q=>q, Q_N=>q_n);
  
end latch_arch;
