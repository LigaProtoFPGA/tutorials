--
-- Implementação dos módulos a serem usados na construção de pares 
--		entidade/arquitetura hier'aquicos para modelar o Hw de um dos
--		flip-flops D do CI TTL 74LS74
--	
--	'Ultima atualiza'c~ao: 22/08/2025
--

--
--	Implementação de uma porta NAND de 3 entradas (primariamente proposta
--		para uso na construção de um dos flip-flops D do CI TTL 74LS74)
--
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity nand3i is
    Port ( A : in  STD_LOGIC;
           B : in  STD_LOGIC;
           C : in  STD_LOGIC;
           Outp : out  STD_LOGIC);
end nand3i;

architecture nand3i of nand3i is

begin

	Outp <= not (A and B and C);

end nand3i;

--
--	Implementação de um latch com 4 entradas e 2 saídas (primariamente proposto
--		para uso na construção de um dos flip-flops D do CI TTL 74LS74)
--
library IEEE;
use IEEE.STD_LOGIC_1164.ALL;

entity latch_4ctrls is
    Port ( C1 : in  STD_LOGIC;
           C2 : in  STD_LOGIC;
           C3 : in  STD_LOGIC;
           C4 : in  STD_LOGIC;
           Q : out  STD_LOGIC;
           Q_N : out  STD_LOGIC
			  );
end latch_4ctrls;

architecture latch_4ctrls of latch_4ctrls is
signal	Q_int, Q_N_int : std_logic;

begin

	Q_int 	<= not (C1 and C2 and Q_N_int);
	Q_N_int	<= not (Q_int and C3 and C4);
	
	Q		<= Q_int;
	Q_N		<= Q_N_int;

end latch_4ctrls;
