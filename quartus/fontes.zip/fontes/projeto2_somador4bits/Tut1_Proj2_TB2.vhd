--
-- A more elaborated testbench for the soma4b adder Hw - generates the complete set
--	of truth table inputs for the adder.
--
--	Created by Ney Calazans
--	Last modified in 23/08/2025
--
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

entity soma4b_tb2 is
end soma4b_tb2;

architecture soma4b_tb2 of soma4b_tb2 is
  signal aa	  : std_logic_vector(3 downto 0):="0000"; -- Estas inicializa,c~oes 
  signal bb	  : std_logic_vector(3 downto 0):="0000"; -- 	funcionam apenas para
  signal soma : std_logic_vector(3 downto 0):="0000"; -- 	simula,c~ao!!
begin

  UTT : entity work.soma4b
        port map ( A => aa, B => bb, 
                   Sum => soma);

	process (aa)--gera todos os 16 valores de aa um a cada 10ns
		begin
			if (aa/=x"F") then
				aa <= aa+x"1" after 10ns;  -- A cada 10ns
			else aa <= x"0" after 10ns;    -- 	incrementa A
		end if;
	end process;

	process (bb)--gera todos valores de bb, um a cada 160ns
		begin
			if (bb/=x"F") then
				bb <= bb+x"1" after 160ns;  -- A cada 16
			else bb <= x"0" after 160ns; 	-- 	valores de A,
		end if;                      		-- 	incrementa B
	end process;

end soma4b_tb2;