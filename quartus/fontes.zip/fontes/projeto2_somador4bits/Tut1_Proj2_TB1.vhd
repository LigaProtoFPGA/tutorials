--
-- Exemplo de testbench simples para o Hw soma4b - só alguns testes aleatórios
--
--	'Ultima atualiza'c~ao: 22/08/2025
--
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;

entity soma4b_tb1 is
end soma4b_tb1;

architecture soma4b_tb1 of soma4b_tb1 is
  signal aa	  : std_logic_vector(3 downto 0):="0000"; -- Estas inicializa,c~oes 
  signal bb	  : std_logic_vector(3 downto 0):="0000"; -- 	funcionam apenas para
  signal soma : std_logic_vector(3 downto 0):="0000"; -- 	simula,c~ao!!
begin

  UTT : entity work.soma4b
        port map ( A => aa, B => bb, 
                   Sum => soma);

	aa <= x"9", x"5" after 10 ns, x"A" after 20 ns, x"B" after 30 ns;
	bb <= x"8", x"3" after 20 ns;

end soma4b_tb1;
