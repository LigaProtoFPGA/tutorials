--
--	A 4-bit adder with 2 inputs, which produces as output a 4-bit result.
--
--	Created by Ney Calazans
--	Last modified in 23/08/2025
--
library IEEE;
use IEEE.std_logic_1164.all;
use IEEE.std_logic_unsigned.all;
	-- The package std_logic_unsigned overloads the '+' operator for the
	-- 	std_logic and std_logic_vector types 

entity soma4b is
port (A, B : in  std_logic_vector(3 downto 0);
      Sum  : out std_logic_vector(3 downto 0)
		);
end soma4b;

architecture soma4b of soma4b is
begin
  Sum  <= A + B;	-- This code creates the Hw to add the 2 input values
					--	present in the A and B 4-bit inputs
end soma4b;

